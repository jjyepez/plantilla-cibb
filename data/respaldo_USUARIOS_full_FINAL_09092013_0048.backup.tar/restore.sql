create temporary table pgdump_restore_path(p text);
--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
-- Edit the following to match the path where the
-- tar archive has been extracted.
--
insert into pgdump_restore_path values('/tmp');

--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = seguridad, pg_catalog;

ALTER TABLE ONLY seguridad.t_logs DROP CONSTRAINT t_logs_codigo_usuario_fkey;
DROP INDEX seguridad.index_cedula;
ALTER TABLE ONLY seguridad.t_usuarios_roles DROP CONSTRAINT unique_id_usuarios_roles;
ALTER TABLE ONLY seguridad.t_personas DROP CONSTRAINT unique_id_t_personas;
ALTER TABLE ONLY seguridad.t_usuarios_sistemas_negados DROP CONSTRAINT unique_id_sistemas_negados;
ALTER TABLE ONLY seguridad.t_sistemas DROP CONSTRAINT unique_id_sistemas;
ALTER TABLE ONLY seguridad.t_sesiones_usuarios DROP CONSTRAINT unique_id_sesiones;
ALTER TABLE ONLY seguridad.t_usuarios_permisos_negados DROP CONSTRAINT unique_id_permisos_negados;
ALTER TABLE ONLY seguridad.t_usuarios_modulos_negados DROP CONSTRAINT unique_id_modulos_negados;
ALTER TABLE ONLY seguridad.t_modulos DROP CONSTRAINT unique_id_modulos;
ALTER TABLE ONLY seguridad.t_estatus_usuarios DROP CONSTRAINT unique_id_estatus_usuarios;
ALTER TABLE ONLY seguridad.t_usuarios_sistemas_negados DROP CONSTRAINT t_usuarios_sistemas_negados_id_key;
ALTER TABLE ONLY seguridad.t_usuarios DROP CONSTRAINT t_usuarios_pkey;
ALTER TABLE ONLY seguridad.t_usuarios_permisos_negados DROP CONSTRAINT t_usuarios_permisos_negados_id_key;
ALTER TABLE ONLY seguridad.t_usuarios_modulos_negados DROP CONSTRAINT t_usuarios_modulos_negados_id_key;
ALTER TABLE ONLY seguridad.t_usuarios DROP CONSTRAINT t_usuarios_id_key;
ALTER TABLE ONLY seguridad.t_sistemas DROP CONSTRAINT t_sistemas_pkey;
ALTER TABLE ONLY seguridad.t_roles DROP CONSTRAINT t_roles_pkey;
ALTER TABLE ONLY seguridad.t_roles DROP CONSTRAINT t_roles_id_key;
ALTER TABLE ONLY seguridad.t_personas DROP CONSTRAINT t_personas_pkey;
ALTER TABLE ONLY seguridad.t_permisos DROP CONSTRAINT t_permisos_pkey;
ALTER TABLE ONLY seguridad.t_permisos DROP CONSTRAINT t_permisos_id_key;
ALTER TABLE ONLY seguridad.t_modulos DROP CONSTRAINT t_modulos_pkey;
ALTER TABLE ONLY seguridad.t_logs DROP CONSTRAINT t_logs_pkey;
ALTER TABLE ONLY seguridad.t_estatus_usuarios DROP CONSTRAINT t_estatus_usuarios_pkey;
ALTER TABLE seguridad.t_usuarios_sistemas_negados ALTER COLUMN id DROP DEFAULT;
ALTER TABLE seguridad.t_usuarios_roles ALTER COLUMN id DROP DEFAULT;
ALTER TABLE seguridad.t_usuarios_permisos_negados ALTER COLUMN id DROP DEFAULT;
ALTER TABLE seguridad.t_usuarios_modulos_negados ALTER COLUMN id DROP DEFAULT;
ALTER TABLE seguridad.t_usuarios ALTER COLUMN id DROP DEFAULT;
ALTER TABLE seguridad.t_sistemas ALTER COLUMN id DROP DEFAULT;
ALTER TABLE seguridad.t_sesiones_usuarios ALTER COLUMN id DROP DEFAULT;
ALTER TABLE seguridad.t_roles ALTER COLUMN id DROP DEFAULT;
ALTER TABLE seguridad.t_personas ALTER COLUMN id DROP DEFAULT;
ALTER TABLE seguridad.t_permisos ALTER COLUMN id DROP DEFAULT;
ALTER TABLE seguridad.t_modulos ALTER COLUMN id DROP DEFAULT;
ALTER TABLE seguridad.t_logs ALTER COLUMN id DROP DEFAULT;
ALTER TABLE seguridad.t_estatus_usuarios ALTER COLUMN id DROP DEFAULT;
DROP VIEW seguridad.v_informacion_usuarios;
DROP SEQUENCE seguridad.t_usuarios_sistemas_negados_id_seq;
DROP TABLE seguridad.t_usuarios_sistemas_negados;
DROP SEQUENCE seguridad.t_usuarios_roles_id_seq;
DROP TABLE seguridad.t_usuarios_roles;
DROP SEQUENCE seguridad.t_usuarios_permisos_negados_id_seq;
DROP TABLE seguridad.t_usuarios_permisos_negados;
DROP SEQUENCE seguridad.t_usuarios_modulos_negados_id_seq;
DROP TABLE seguridad.t_usuarios_modulos_negados;
DROP SEQUENCE seguridad.t_usuarios_id_seq;
DROP TABLE seguridad.t_usuarios;
DROP SEQUENCE seguridad.t_sistemas_id_seq;
DROP TABLE seguridad.t_sistemas;
DROP SEQUENCE seguridad.t_sesiones_usuarios_id_seq;
DROP TABLE seguridad.t_sesiones_usuarios;
DROP SEQUENCE seguridad.t_roles_id_seq;
DROP TABLE seguridad.t_roles;
DROP SEQUENCE seguridad.t_personas_id_seq;
DROP TABLE seguridad.t_personas;
DROP SEQUENCE seguridad.t_permisos_id_seq;
DROP TABLE seguridad.t_permisos;
DROP SEQUENCE seguridad.t_modulos_id_seq;
DROP TABLE seguridad.t_modulos;
DROP SEQUENCE seguridad.t_logs_id_seq;
DROP TABLE seguridad.t_logs;
DROP SEQUENCE seguridad.t_estatus_usuarios_id_seq;
DROP TABLE seguridad.t_estatus_usuarios;
DROP SCHEMA seguridad;
--
-- Name: seguridad; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA seguridad;


ALTER SCHEMA seguridad OWNER TO postgres;

SET search_path = seguridad, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: t_estatus_usuarios; Type: TABLE; Schema: seguridad; Owner: postgres; Tablespace: 
--

CREATE TABLE t_estatus_usuarios (
    id integer NOT NULL,
    codigo_estatus_usuarios character varying(6) NOT NULL,
    nombre_estatus character varying(100) NOT NULL,
    descripcion_estatus character varying(255) NOT NULL
);


ALTER TABLE seguridad.t_estatus_usuarios OWNER TO postgres;

--
-- Name: t_estatus_usuarios_id_seq; Type: SEQUENCE; Schema: seguridad; Owner: postgres
--

CREATE SEQUENCE t_estatus_usuarios_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE seguridad.t_estatus_usuarios_id_seq OWNER TO postgres;

--
-- Name: t_estatus_usuarios_id_seq; Type: SEQUENCE OWNED BY; Schema: seguridad; Owner: postgres
--

ALTER SEQUENCE t_estatus_usuarios_id_seq OWNED BY t_estatus_usuarios.id;


--
-- Name: t_estatus_usuarios_id_seq; Type: SEQUENCE SET; Schema: seguridad; Owner: postgres
--

SELECT pg_catalog.setval('t_estatus_usuarios_id_seq', 1, false);


--
-- Name: t_logs; Type: TABLE; Schema: seguridad; Owner: postgres; Tablespace: 
--

CREATE TABLE t_logs (
    id integer NOT NULL,
    evento text,
    codigo_usuario character varying(6),
    momento character varying(100)
);


ALTER TABLE seguridad.t_logs OWNER TO postgres;

--
-- Name: t_logs_id_seq; Type: SEQUENCE; Schema: seguridad; Owner: postgres
--

CREATE SEQUENCE t_logs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE seguridad.t_logs_id_seq OWNER TO postgres;

--
-- Name: t_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: seguridad; Owner: postgres
--

ALTER SEQUENCE t_logs_id_seq OWNED BY t_logs.id;


--
-- Name: t_logs_id_seq; Type: SEQUENCE SET; Schema: seguridad; Owner: postgres
--

SELECT pg_catalog.setval('t_logs_id_seq', 1, false);


--
-- Name: t_modulos; Type: TABLE; Schema: seguridad; Owner: postgres; Tablespace: 
--

CREATE TABLE t_modulos (
    id integer NOT NULL,
    codigo_modulo character varying(6) NOT NULL,
    nombre_modulo character varying(100) NOT NULL,
    descripcion_modulo character varying(255),
    codigo_sistema character varying(6) NOT NULL
);


ALTER TABLE seguridad.t_modulos OWNER TO postgres;

--
-- Name: t_modulos_id_seq; Type: SEQUENCE; Schema: seguridad; Owner: postgres
--

CREATE SEQUENCE t_modulos_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE seguridad.t_modulos_id_seq OWNER TO postgres;

--
-- Name: t_modulos_id_seq; Type: SEQUENCE OWNED BY; Schema: seguridad; Owner: postgres
--

ALTER SEQUENCE t_modulos_id_seq OWNED BY t_modulos.id;


--
-- Name: t_modulos_id_seq; Type: SEQUENCE SET; Schema: seguridad; Owner: postgres
--

SELECT pg_catalog.setval('t_modulos_id_seq', 1, false);


--
-- Name: t_permisos; Type: TABLE; Schema: seguridad; Owner: usuario_base; Tablespace: 
--

CREATE TABLE t_permisos (
    id integer NOT NULL,
    codigo_permiso character varying(6) NOT NULL,
    codigo_modulo character varying(6) NOT NULL,
    nombre_permiso character varying(100),
    descripcion_permiso character varying(255)
);


ALTER TABLE seguridad.t_permisos OWNER TO usuario_base;

--
-- Name: t_permisos_id_seq; Type: SEQUENCE; Schema: seguridad; Owner: usuario_base
--

CREATE SEQUENCE t_permisos_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE seguridad.t_permisos_id_seq OWNER TO usuario_base;

--
-- Name: t_permisos_id_seq; Type: SEQUENCE OWNED BY; Schema: seguridad; Owner: usuario_base
--

ALTER SEQUENCE t_permisos_id_seq OWNED BY t_permisos.id;


--
-- Name: t_permisos_id_seq; Type: SEQUENCE SET; Schema: seguridad; Owner: usuario_base
--

SELECT pg_catalog.setval('t_permisos_id_seq', 1, false);


--
-- Name: t_personas; Type: TABLE; Schema: seguridad; Owner: postgres; Tablespace: 
--

CREATE TABLE t_personas (
    id integer NOT NULL,
    codigo_persona character varying(6) NOT NULL,
    nombres character varying(255) NOT NULL,
    apellidos character varying(255) NOT NULL,
    cedula character varying(10) NOT NULL,
    correo_electronico character varying(255) NOT NULL
);


ALTER TABLE seguridad.t_personas OWNER TO postgres;

--
-- Name: TABLE t_personas; Type: COMMENT; Schema: seguridad; Owner: postgres
--

COMMENT ON TABLE t_personas IS 'ESTA TABLA FUE CREADA SOLO POR MOTIVOS DE PRUEBAS .... DEBE SER CREADA CORRECTAMENTE EN EL ESQUEMA CORRESPONDIENTE A SU RESPECTIVO SISTEMA .... jjy';


--
-- Name: t_personas_id_seq; Type: SEQUENCE; Schema: seguridad; Owner: postgres
--

CREATE SEQUENCE t_personas_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE seguridad.t_personas_id_seq OWNER TO postgres;

--
-- Name: t_personas_id_seq; Type: SEQUENCE OWNED BY; Schema: seguridad; Owner: postgres
--

ALTER SEQUENCE t_personas_id_seq OWNED BY t_personas.id;


--
-- Name: t_personas_id_seq; Type: SEQUENCE SET; Schema: seguridad; Owner: postgres
--

SELECT pg_catalog.setval('t_personas_id_seq', 1, false);


--
-- Name: t_roles; Type: TABLE; Schema: seguridad; Owner: usuario_base; Tablespace: 
--

CREATE TABLE t_roles (
    id integer NOT NULL,
    codigo_rol character varying(6) NOT NULL,
    nombre_rol character varying(100),
    descripcion_rol character varying(255)
);


ALTER TABLE seguridad.t_roles OWNER TO usuario_base;

--
-- Name: t_roles_id_seq; Type: SEQUENCE; Schema: seguridad; Owner: usuario_base
--

CREATE SEQUENCE t_roles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE seguridad.t_roles_id_seq OWNER TO usuario_base;

--
-- Name: t_roles_id_seq; Type: SEQUENCE OWNED BY; Schema: seguridad; Owner: usuario_base
--

ALTER SEQUENCE t_roles_id_seq OWNED BY t_roles.id;


--
-- Name: t_roles_id_seq; Type: SEQUENCE SET; Schema: seguridad; Owner: usuario_base
--

SELECT pg_catalog.setval('t_roles_id_seq', 1, false);


--
-- Name: t_sesiones_usuarios; Type: TABLE; Schema: seguridad; Owner: postgres; Tablespace: 
--

CREATE TABLE t_sesiones_usuarios (
    id integer NOT NULL,
    codigo_usuario character varying(6) NOT NULL,
    hash_sesion character varying(255) NOT NULL,
    codigo_estatus character varying(6) NOT NULL,
    momento timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE seguridad.t_sesiones_usuarios OWNER TO postgres;

--
-- Name: t_sesiones_usuarios_id_seq; Type: SEQUENCE; Schema: seguridad; Owner: postgres
--

CREATE SEQUENCE t_sesiones_usuarios_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE seguridad.t_sesiones_usuarios_id_seq OWNER TO postgres;

--
-- Name: t_sesiones_usuarios_id_seq; Type: SEQUENCE OWNED BY; Schema: seguridad; Owner: postgres
--

ALTER SEQUENCE t_sesiones_usuarios_id_seq OWNED BY t_sesiones_usuarios.id;


--
-- Name: t_sesiones_usuarios_id_seq; Type: SEQUENCE SET; Schema: seguridad; Owner: postgres
--

SELECT pg_catalog.setval('t_sesiones_usuarios_id_seq', 194, true);


--
-- Name: t_sistemas; Type: TABLE; Schema: seguridad; Owner: postgres; Tablespace: 
--

CREATE TABLE t_sistemas (
    id integer NOT NULL,
    codigo_sistema character varying(6) NOT NULL,
    nombre_sistema character varying(100) NOT NULL,
    descripcion_sistema character varying(255)
);


ALTER TABLE seguridad.t_sistemas OWNER TO postgres;

--
-- Name: t_sistemas_id_seq; Type: SEQUENCE; Schema: seguridad; Owner: postgres
--

CREATE SEQUENCE t_sistemas_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE seguridad.t_sistemas_id_seq OWNER TO postgres;

--
-- Name: t_sistemas_id_seq; Type: SEQUENCE OWNED BY; Schema: seguridad; Owner: postgres
--

ALTER SEQUENCE t_sistemas_id_seq OWNED BY t_sistemas.id;


--
-- Name: t_sistemas_id_seq; Type: SEQUENCE SET; Schema: seguridad; Owner: postgres
--

SELECT pg_catalog.setval('t_sistemas_id_seq', 1, false);


--
-- Name: t_usuarios; Type: TABLE; Schema: seguridad; Owner: usuario_base; Tablespace: 
--

CREATE TABLE t_usuarios (
    id integer NOT NULL,
    codigo_usuario character varying(6) NOT NULL,
    nombre_usuario character varying(100),
    contrasena character varying(20),
    codigo_persona character varying(6),
    codigo_estatus character varying(6)
);


ALTER TABLE seguridad.t_usuarios OWNER TO usuario_base;

--
-- Name: t_usuarios_id_seq; Type: SEQUENCE; Schema: seguridad; Owner: usuario_base
--

CREATE SEQUENCE t_usuarios_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE seguridad.t_usuarios_id_seq OWNER TO usuario_base;

--
-- Name: t_usuarios_id_seq; Type: SEQUENCE OWNED BY; Schema: seguridad; Owner: usuario_base
--

ALTER SEQUENCE t_usuarios_id_seq OWNED BY t_usuarios.id;


--
-- Name: t_usuarios_id_seq; Type: SEQUENCE SET; Schema: seguridad; Owner: usuario_base
--

SELECT pg_catalog.setval('t_usuarios_id_seq', 1, true);


--
-- Name: t_usuarios_modulos_negados; Type: TABLE; Schema: seguridad; Owner: postgres; Tablespace: 
--

CREATE TABLE t_usuarios_modulos_negados (
    codigo_rol character varying(6) NOT NULL,
    codigo_modulo_negado character varying(6) NOT NULL,
    id integer NOT NULL
);


ALTER TABLE seguridad.t_usuarios_modulos_negados OWNER TO postgres;

--
-- Name: t_usuarios_modulos_negados_id_seq; Type: SEQUENCE; Schema: seguridad; Owner: postgres
--

CREATE SEQUENCE t_usuarios_modulos_negados_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE seguridad.t_usuarios_modulos_negados_id_seq OWNER TO postgres;

--
-- Name: t_usuarios_modulos_negados_id_seq; Type: SEQUENCE OWNED BY; Schema: seguridad; Owner: postgres
--

ALTER SEQUENCE t_usuarios_modulos_negados_id_seq OWNED BY t_usuarios_modulos_negados.id;


--
-- Name: t_usuarios_modulos_negados_id_seq; Type: SEQUENCE SET; Schema: seguridad; Owner: postgres
--

SELECT pg_catalog.setval('t_usuarios_modulos_negados_id_seq', 1, false);


--
-- Name: t_usuarios_permisos_negados; Type: TABLE; Schema: seguridad; Owner: postgres; Tablespace: 
--

CREATE TABLE t_usuarios_permisos_negados (
    codigo_permiso_negado character varying(6) NOT NULL,
    codigo_rol character varying(6) NOT NULL,
    id integer NOT NULL,
    codigo_modulo character varying(6) NOT NULL
);


ALTER TABLE seguridad.t_usuarios_permisos_negados OWNER TO postgres;

--
-- Name: t_usuarios_permisos_negados_id_seq; Type: SEQUENCE; Schema: seguridad; Owner: postgres
--

CREATE SEQUENCE t_usuarios_permisos_negados_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE seguridad.t_usuarios_permisos_negados_id_seq OWNER TO postgres;

--
-- Name: t_usuarios_permisos_negados_id_seq; Type: SEQUENCE OWNED BY; Schema: seguridad; Owner: postgres
--

ALTER SEQUENCE t_usuarios_permisos_negados_id_seq OWNED BY t_usuarios_permisos_negados.id;


--
-- Name: t_usuarios_permisos_negados_id_seq; Type: SEQUENCE SET; Schema: seguridad; Owner: postgres
--

SELECT pg_catalog.setval('t_usuarios_permisos_negados_id_seq', 1, false);


--
-- Name: t_usuarios_roles; Type: TABLE; Schema: seguridad; Owner: postgres; Tablespace: 
--

CREATE TABLE t_usuarios_roles (
    id integer NOT NULL,
    codigo_rol character varying(6) NOT NULL,
    codigo_usuario character varying(6) NOT NULL
);


ALTER TABLE seguridad.t_usuarios_roles OWNER TO postgres;

--
-- Name: t_usuarios_roles_id_seq; Type: SEQUENCE; Schema: seguridad; Owner: postgres
--

CREATE SEQUENCE t_usuarios_roles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE seguridad.t_usuarios_roles_id_seq OWNER TO postgres;

--
-- Name: t_usuarios_roles_id_seq; Type: SEQUENCE OWNED BY; Schema: seguridad; Owner: postgres
--

ALTER SEQUENCE t_usuarios_roles_id_seq OWNED BY t_usuarios_roles.id;


--
-- Name: t_usuarios_roles_id_seq; Type: SEQUENCE SET; Schema: seguridad; Owner: postgres
--

SELECT pg_catalog.setval('t_usuarios_roles_id_seq', 1, false);


--
-- Name: t_usuarios_sistemas_negados; Type: TABLE; Schema: seguridad; Owner: postgres; Tablespace: 
--

CREATE TABLE t_usuarios_sistemas_negados (
    codigo_usuario character varying(6) NOT NULL,
    codigo_sistema_negado character varying NOT NULL,
    id integer NOT NULL
);


ALTER TABLE seguridad.t_usuarios_sistemas_negados OWNER TO postgres;

--
-- Name: t_usuarios_sistemas_negados_id_seq; Type: SEQUENCE; Schema: seguridad; Owner: postgres
--

CREATE SEQUENCE t_usuarios_sistemas_negados_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE seguridad.t_usuarios_sistemas_negados_id_seq OWNER TO postgres;

--
-- Name: t_usuarios_sistemas_negados_id_seq; Type: SEQUENCE OWNED BY; Schema: seguridad; Owner: postgres
--

ALTER SEQUENCE t_usuarios_sistemas_negados_id_seq OWNED BY t_usuarios_sistemas_negados.id;


--
-- Name: t_usuarios_sistemas_negados_id_seq; Type: SEQUENCE SET; Schema: seguridad; Owner: postgres
--

SELECT pg_catalog.setval('t_usuarios_sistemas_negados_id_seq', 1, false);


--
-- Name: v_informacion_usuarios; Type: VIEW; Schema: seguridad; Owner: postgres
--

CREATE VIEW v_informacion_usuarios AS
    SELECT u.id, u.codigo_usuario, u.nombre_usuario, u.contrasena, u.codigo_persona, u.codigo_estatus, ur.codigo_rol, p.cedula, p.nombres, p.apellidos, p.correo_electronico, su.nombre_estatus AS estatus_usuario, ru.nombre_rol AS rol_usuario FROM ((((t_usuarios u LEFT JOIN t_personas p ON (((p.codigo_persona)::text = (u.codigo_persona)::text))) LEFT JOIN t_estatus_usuarios su ON (((su.codigo_estatus_usuarios)::text = (u.codigo_estatus)::text))) LEFT JOIN t_usuarios_roles ur ON (((ur.codigo_usuario)::text = (u.codigo_usuario)::text))) LEFT JOIN t_roles ru ON (((ru.codigo_rol)::text = (ur.codigo_rol)::text)));


ALTER TABLE seguridad.v_informacion_usuarios OWNER TO postgres;

--
-- Name: id; Type: DEFAULT; Schema: seguridad; Owner: postgres
--

ALTER TABLE ONLY t_estatus_usuarios ALTER COLUMN id SET DEFAULT nextval('t_estatus_usuarios_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: seguridad; Owner: postgres
--

ALTER TABLE ONLY t_logs ALTER COLUMN id SET DEFAULT nextval('t_logs_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: seguridad; Owner: postgres
--

ALTER TABLE ONLY t_modulos ALTER COLUMN id SET DEFAULT nextval('t_modulos_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: seguridad; Owner: usuario_base
--

ALTER TABLE ONLY t_permisos ALTER COLUMN id SET DEFAULT nextval('t_permisos_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: seguridad; Owner: postgres
--

ALTER TABLE ONLY t_personas ALTER COLUMN id SET DEFAULT nextval('t_personas_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: seguridad; Owner: usuario_base
--

ALTER TABLE ONLY t_roles ALTER COLUMN id SET DEFAULT nextval('t_roles_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: seguridad; Owner: postgres
--

ALTER TABLE ONLY t_sesiones_usuarios ALTER COLUMN id SET DEFAULT nextval('t_sesiones_usuarios_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: seguridad; Owner: postgres
--

ALTER TABLE ONLY t_sistemas ALTER COLUMN id SET DEFAULT nextval('t_sistemas_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: seguridad; Owner: usuario_base
--

ALTER TABLE ONLY t_usuarios ALTER COLUMN id SET DEFAULT nextval('t_usuarios_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: seguridad; Owner: postgres
--

ALTER TABLE ONLY t_usuarios_modulos_negados ALTER COLUMN id SET DEFAULT nextval('t_usuarios_modulos_negados_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: seguridad; Owner: postgres
--

ALTER TABLE ONLY t_usuarios_permisos_negados ALTER COLUMN id SET DEFAULT nextval('t_usuarios_permisos_negados_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: seguridad; Owner: postgres
--

ALTER TABLE ONLY t_usuarios_roles ALTER COLUMN id SET DEFAULT nextval('t_usuarios_roles_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: seguridad; Owner: postgres
--

ALTER TABLE ONLY t_usuarios_sistemas_negados ALTER COLUMN id SET DEFAULT nextval('t_usuarios_sistemas_negados_id_seq'::regclass);


--
-- Data for Name: t_estatus_usuarios; Type: TABLE DATA; Schema: seguridad; Owner: postgres
--

COPY t_estatus_usuarios (id, codigo_estatus_usuarios, nombre_estatus, descripcion_estatus) FROM stdin;
\.
copy t_estatus_usuarios (id, codigo_estatus_usuarios, nombre_estatus, descripcion_estatus)  from '$$PATH$$/2085.dat' ;
--
-- Data for Name: t_logs; Type: TABLE DATA; Schema: seguridad; Owner: postgres
--

COPY t_logs (id, evento, codigo_usuario, momento) FROM stdin;
\.
copy t_logs (id, evento, codigo_usuario, momento)  from '$$PATH$$/2083.dat' ;
--
-- Data for Name: t_modulos; Type: TABLE DATA; Schema: seguridad; Owner: postgres
--

COPY t_modulos (id, codigo_modulo, nombre_modulo, descripcion_modulo, codigo_sistema) FROM stdin;
\.
copy t_modulos (id, codigo_modulo, nombre_modulo, descripcion_modulo, codigo_sistema)  from '$$PATH$$/2075.dat' ;
--
-- Data for Name: t_permisos; Type: TABLE DATA; Schema: seguridad; Owner: usuario_base
--

COPY t_permisos (id, codigo_permiso, codigo_modulo, nombre_permiso, descripcion_permiso) FROM stdin;
\.
copy t_permisos (id, codigo_permiso, codigo_modulo, nombre_permiso, descripcion_permiso)  from '$$PATH$$/2076.dat' ;
--
-- Data for Name: t_personas; Type: TABLE DATA; Schema: seguridad; Owner: postgres
--

COPY t_personas (id, codigo_persona, nombres, apellidos, cedula, correo_electronico) FROM stdin;
\.
copy t_personas (id, codigo_persona, nombres, apellidos, cedula, correo_electronico)  from '$$PATH$$/2087.dat' ;
--
-- Data for Name: t_roles; Type: TABLE DATA; Schema: seguridad; Owner: usuario_base
--

COPY t_roles (id, codigo_rol, nombre_rol, descripcion_rol) FROM stdin;
\.
copy t_roles (id, codigo_rol, nombre_rol, descripcion_rol)  from '$$PATH$$/2077.dat' ;
--
-- Data for Name: t_sesiones_usuarios; Type: TABLE DATA; Schema: seguridad; Owner: postgres
--

COPY t_sesiones_usuarios (id, codigo_usuario, hash_sesion, codigo_estatus, momento) FROM stdin;
\.
copy t_sesiones_usuarios (id, codigo_usuario, hash_sesion, codigo_estatus, momento)  from '$$PATH$$/2084.dat' ;
--
-- Data for Name: t_sistemas; Type: TABLE DATA; Schema: seguridad; Owner: postgres
--

COPY t_sistemas (id, codigo_sistema, nombre_sistema, descripcion_sistema) FROM stdin;
\.
copy t_sistemas (id, codigo_sistema, nombre_sistema, descripcion_sistema)  from '$$PATH$$/2078.dat' ;
--
-- Data for Name: t_usuarios; Type: TABLE DATA; Schema: seguridad; Owner: usuario_base
--

COPY t_usuarios (id, codigo_usuario, nombre_usuario, contrasena, codigo_persona, codigo_estatus) FROM stdin;
\.
copy t_usuarios (id, codigo_usuario, nombre_usuario, contrasena, codigo_persona, codigo_estatus)  from '$$PATH$$/2079.dat' ;
--
-- Data for Name: t_usuarios_modulos_negados; Type: TABLE DATA; Schema: seguridad; Owner: postgres
--

COPY t_usuarios_modulos_negados (codigo_rol, codigo_modulo_negado, id) FROM stdin;
\.
copy t_usuarios_modulos_negados (codigo_rol, codigo_modulo_negado, id)  from '$$PATH$$/2080.dat' ;
--
-- Data for Name: t_usuarios_permisos_negados; Type: TABLE DATA; Schema: seguridad; Owner: postgres
--

COPY t_usuarios_permisos_negados (codigo_permiso_negado, codigo_rol, id, codigo_modulo) FROM stdin;
\.
copy t_usuarios_permisos_negados (codigo_permiso_negado, codigo_rol, id, codigo_modulo)  from '$$PATH$$/2081.dat' ;
--
-- Data for Name: t_usuarios_roles; Type: TABLE DATA; Schema: seguridad; Owner: postgres
--

COPY t_usuarios_roles (id, codigo_rol, codigo_usuario) FROM stdin;
\.
copy t_usuarios_roles (id, codigo_rol, codigo_usuario)  from '$$PATH$$/2086.dat' ;
--
-- Data for Name: t_usuarios_sistemas_negados; Type: TABLE DATA; Schema: seguridad; Owner: postgres
--

COPY t_usuarios_sistemas_negados (codigo_usuario, codigo_sistema_negado, id) FROM stdin;
\.
copy t_usuarios_sistemas_negados (codigo_usuario, codigo_sistema_negado, id)  from '$$PATH$$/2082.dat' ;
--
-- Name: t_estatus_usuarios_pkey; Type: CONSTRAINT; Schema: seguridad; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY t_estatus_usuarios
    ADD CONSTRAINT t_estatus_usuarios_pkey PRIMARY KEY (codigo_estatus_usuarios);


--
-- Name: t_logs_pkey; Type: CONSTRAINT; Schema: seguridad; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY t_logs
    ADD CONSTRAINT t_logs_pkey PRIMARY KEY (id);


--
-- Name: t_modulos_pkey; Type: CONSTRAINT; Schema: seguridad; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY t_modulos
    ADD CONSTRAINT t_modulos_pkey PRIMARY KEY (codigo_modulo);


--
-- Name: t_permisos_id_key; Type: CONSTRAINT; Schema: seguridad; Owner: usuario_base; Tablespace: 
--

ALTER TABLE ONLY t_permisos
    ADD CONSTRAINT t_permisos_id_key UNIQUE (id);


--
-- Name: t_permisos_pkey; Type: CONSTRAINT; Schema: seguridad; Owner: usuario_base; Tablespace: 
--

ALTER TABLE ONLY t_permisos
    ADD CONSTRAINT t_permisos_pkey PRIMARY KEY (codigo_permiso);


--
-- Name: t_personas_pkey; Type: CONSTRAINT; Schema: seguridad; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY t_personas
    ADD CONSTRAINT t_personas_pkey PRIMARY KEY (codigo_persona);


--
-- Name: t_roles_id_key; Type: CONSTRAINT; Schema: seguridad; Owner: usuario_base; Tablespace: 
--

ALTER TABLE ONLY t_roles
    ADD CONSTRAINT t_roles_id_key UNIQUE (id);


--
-- Name: t_roles_pkey; Type: CONSTRAINT; Schema: seguridad; Owner: usuario_base; Tablespace: 
--

ALTER TABLE ONLY t_roles
    ADD CONSTRAINT t_roles_pkey PRIMARY KEY (codigo_rol);


--
-- Name: t_sistemas_pkey; Type: CONSTRAINT; Schema: seguridad; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY t_sistemas
    ADD CONSTRAINT t_sistemas_pkey PRIMARY KEY (codigo_sistema);


--
-- Name: t_usuarios_id_key; Type: CONSTRAINT; Schema: seguridad; Owner: usuario_base; Tablespace: 
--

ALTER TABLE ONLY t_usuarios
    ADD CONSTRAINT t_usuarios_id_key UNIQUE (id);


--
-- Name: t_usuarios_modulos_negados_id_key; Type: CONSTRAINT; Schema: seguridad; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY t_usuarios_modulos_negados
    ADD CONSTRAINT t_usuarios_modulos_negados_id_key UNIQUE (id);


--
-- Name: t_usuarios_permisos_negados_id_key; Type: CONSTRAINT; Schema: seguridad; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY t_usuarios_permisos_negados
    ADD CONSTRAINT t_usuarios_permisos_negados_id_key UNIQUE (id);


--
-- Name: t_usuarios_pkey; Type: CONSTRAINT; Schema: seguridad; Owner: usuario_base; Tablespace: 
--

ALTER TABLE ONLY t_usuarios
    ADD CONSTRAINT t_usuarios_pkey PRIMARY KEY (codigo_usuario);


--
-- Name: t_usuarios_sistemas_negados_id_key; Type: CONSTRAINT; Schema: seguridad; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY t_usuarios_sistemas_negados
    ADD CONSTRAINT t_usuarios_sistemas_negados_id_key UNIQUE (id);


--
-- Name: unique_id_estatus_usuarios; Type: CONSTRAINT; Schema: seguridad; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY t_estatus_usuarios
    ADD CONSTRAINT unique_id_estatus_usuarios UNIQUE (id);


--
-- Name: unique_id_modulos; Type: CONSTRAINT; Schema: seguridad; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY t_modulos
    ADD CONSTRAINT unique_id_modulos UNIQUE (id);


--
-- Name: unique_id_modulos_negados; Type: CONSTRAINT; Schema: seguridad; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY t_usuarios_modulos_negados
    ADD CONSTRAINT unique_id_modulos_negados UNIQUE (id);


--
-- Name: unique_id_permisos_negados; Type: CONSTRAINT; Schema: seguridad; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY t_usuarios_permisos_negados
    ADD CONSTRAINT unique_id_permisos_negados UNIQUE (id);


--
-- Name: unique_id_sesiones; Type: CONSTRAINT; Schema: seguridad; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY t_sesiones_usuarios
    ADD CONSTRAINT unique_id_sesiones UNIQUE (id);


--
-- Name: unique_id_sistemas; Type: CONSTRAINT; Schema: seguridad; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY t_sistemas
    ADD CONSTRAINT unique_id_sistemas UNIQUE (id);


--
-- Name: unique_id_sistemas_negados; Type: CONSTRAINT; Schema: seguridad; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY t_usuarios_sistemas_negados
    ADD CONSTRAINT unique_id_sistemas_negados UNIQUE (id);


--
-- Name: unique_id_t_personas; Type: CONSTRAINT; Schema: seguridad; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY t_personas
    ADD CONSTRAINT unique_id_t_personas UNIQUE (id);


--
-- Name: unique_id_usuarios_roles; Type: CONSTRAINT; Schema: seguridad; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY t_usuarios_roles
    ADD CONSTRAINT unique_id_usuarios_roles UNIQUE (id);


--
-- Name: index_cedula; Type: INDEX; Schema: seguridad; Owner: postgres; Tablespace: 
--

CREATE INDEX index_cedula ON t_personas USING btree (cedula);


--
-- Name: t_logs_codigo_usuario_fkey; Type: FK CONSTRAINT; Schema: seguridad; Owner: postgres
--

ALTER TABLE ONLY t_logs
    ADD CONSTRAINT t_logs_codigo_usuario_fkey FOREIGN KEY (codigo_usuario) REFERENCES t_usuarios(codigo_usuario);


--
-- PostgreSQL database dump complete
--

